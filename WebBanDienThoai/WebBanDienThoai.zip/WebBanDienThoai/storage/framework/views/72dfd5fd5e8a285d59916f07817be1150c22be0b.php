

<?php $__env->startSection('content'); ?>
<main class="addproduct-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <h3 class="card-header text-center">Thêm Sản Phẩm</h3>
                    <div class="card-body">
                        <form action="<?php echo e(route('product.addproduct')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Danh mục</span></div>
                                            <div class="col-md-9">
                                                <select id="id_category" name="id_category" class="form-control"
                                                    required autofocus onchange="handleCategoryChange()">
                                                    <option value="" disabled selected hidden>--Chọn danh mục--</option>
                                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id_category); ?>">
                                                        <?php echo e($category->name_category); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <input type="hidden" id="selected_category" name="selected_category" value="">
                                            </div>
                                        </div>
                                        <?php if($errors->has('id_category')): ?>
                                        <span class="text-danger"> $errors->first('id_category')</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Hãng sản xuất</span></div>
                                            <div class="col-md-9">
                                                <select id="id_manufacturer" name="id_manufacturer"
                                                    class="form-control" required autofocus onchange="handleManufacturerChange()">
                                                    <option value="" disabled selected hidden>--Chọn hãng sản xuất--</option>
                                                    <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($manufacturer->id_manufacturer); ?>">
                                                        <?php echo e($manufacturer->name_manufacturer); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <input type="hidden" id="selected_manufacturer" name="selected_manufacturer" value="">
                                            </div>
                                        </div>
                                        <?php if($errors->has('id_manufacturer')): ?>
                                        <span class="text-danger"> $errors->first('id_manufacturer')</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Tên sản phẩm</span></div>
                                            <div class="col-md-9"> <input type="text" id="name_product"
                                                    class="form-control" name="name_product" required autofocus></div>
                                        </div>
                                        <?php if($errors->has('name_product')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('name_product')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Số lượng</span></div>
                                            <div class="col-md-9"> <input type="text" id="quantity_product"
                                                    class="form-control" name="quantity_product" required autofocus>
                                            </div>
                                        </div>
                                        <?php if($errors->has('quantity_product')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('quantity_product')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Giá</span></div>
                                            <div class="col-md-9"> <input type="text" id="price_product"
                                                    class="form-control" name="price_product" required autofocus></div>
                                        </div>
                                        <?php if($errors->has('price_product')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('price_product')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Ảnh sản phẩm</span></div>
                                            <div class="col-md-9"><input type="file" id="fileToUpload"
                                                    class="form-control" name="image_address_product" required></div>
                                        </div>

                                        <?php if($errors->has('image_address_product')): ?>
                                        <span class="text-danger"> $errors->first('image_address_product')</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Mô tả</span></div>
                                            <div class="col-md-9"> <input type="text" id="describe_product"
                                                    class="form-control" name="describe_product" required autofocus>
                                            </div>
                                        </div>
                                        <?php if($errors->has('describe_product')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('describe_product')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="row">
                                            <div class="col-md-3"><span>Thông số</span></div>
                                            <div class="col-md-9"> <input type="text" id="specifications"
                                                    class="form-control" name="specifications" required autofocus></div>
                                        </div>
                                        <?php if($errors->has('specifications')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('specifications')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row btn_login">
                                <div class="col-md-3"></div>
                                <div class="col-md-9">
                                    <div class="row">
                                        <div class="col-md-6"><a href="#"></a>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="d-grid mx-auto">
                                                <button type="submit" class="btn btn-primary btn-block">Lưu</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    function handleCategoryChange() {
        var selectedCategory = document.getElementById('id_category').value;
        document.getElementById('selected_category').value = selectedCategory;
    }

    function handleManufacturerChange() {
        var selectedManufacturer = document.getElementById('id_manufacturer').value;
        document.getElementById('selected_manufacturer').value = selectedManufacturer;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBanDienThoai\resources\views/admin/product/addproduct.blade.php ENDPATH**/ ?>