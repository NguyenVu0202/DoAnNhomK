


<!-- Product section-->
<?php $__env->startSection('content'); ?>
<main class="listproduct-form">
    <div class="container px-4 px-lg-5 my-5">
        <div class="row gx-4 gx-lg-5 align-items-center">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-6">
                            <h2>Quản Lý Sản Phẩm</h2>
                        </div>
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('product.addproduct')); ?>" class="btn btn-success" data-toggle="modal"><i
                                    class="bi bi-pencil"></i><span>Thêm Sản Phẩm</span></a>
                        </div>
                    </div>
                </div>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Mã sản phẩm</th>
                            <th>Tên danh mục</th>
                            <th>Tên hãng sản xuất</th>
                            <th>Tên sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Giá</th>
                            <th>Ảnh sản phẩm</th>
                            <th>Mô tả</th>
                            <th>Thông số kỹ thuật</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->id_product); ?></td>
                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->id_category == $category->id_category): ?>
                            <td><?php echo e($category->name_category); ?></td>
                            <?php break; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->id_manufacturer == $manufacturer->id_manufacturer): ?>
                            <td><?php echo e($manufacturer->name_manufacturer); ?></td>
                            <?php break; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <td><?php echo e($product->name_product); ?></td>
                            <td><?php echo e($product->quantity_product); ?></td>
                            <td><?php echo e($product->price_product); ?></td>
                            <td><img src="<?php echo e(asset('uploads/productimage/' . $product->image_address_product)); ?>" alt=""
                                    style="width: 40%;height: 100px;margin: 20px;"></td>
                            <td><?php echo e($product->describe_product); ?></td>
                            <td><?php echo e($product->specifications); ?></td>
                            <td>
                                <a href="<?php echo e(route('product.indexUpdateproduct', ['id' => $product->id_product])); ?>"
                                    class="mx-1">Sửa</a>
                                <a href="<?php echo e(route('product.deleteproduct', ['id' => $product->id_product])); ?>">Xóa</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5"></div>
            <div class="col-md-2"><?php echo e($products->links()); ?></div>
            <div class="col-md-5"></div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBanDienThoai\resources\views/admin/product/listproduct.blade.php ENDPATH**/ ?>