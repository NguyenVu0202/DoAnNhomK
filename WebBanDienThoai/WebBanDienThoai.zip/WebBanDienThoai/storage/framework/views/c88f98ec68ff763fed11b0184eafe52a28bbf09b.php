


<!-- Product section-->
<?php $__env->startSection('content'); ?>
<main class="listmanufacturer-form">
    <div class="container px-4 px-lg-5 my-5">
        <div class="row gx-4 gx-lg-5 align-items-center">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-6">
                            <h2>Quản Lý Hãng Sản Xuất</h2>
                        </div>
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('manufacturer.addmanufacturer')); ?>" class="btn btn-success"
                                data-toggle="modal"><i class="bi bi-pencil"></i><span>Thêm Hãng sản xuất</span></a>
                        </div>
                    </div>
                </div>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Mã Hãng</th>
                            <th>Tên Hãng</th>
                            <th>Ảnh Hãng</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($manufacturer->id_manufacturer); ?></td>
                            <td><?php echo e($manufacturer->name_manufacturer); ?></td>
                            <td><img src="<?php echo e(asset('uploads/manufacturerimage/' . $manufacturer->image_manufacturer)); ?>"
                                    alt="" style="width: 40%;height: 100px;margin: 20px;"></td>
                            <td>
                                <a href="<?php echo e(route('manufacturer.updateindex', ['id' => $manufacturer->id_manufacturer])); ?>"
                                    class="mx-1">Sửa</a>
                                <a
                                    href="<?php echo e(route('manufacturer.deletemanufacturer', ['id' => $manufacturer->id_manufacturer])); ?>">Xóa</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5"></div>
            <div class="col-md-2"><?php echo e($manufacturers->links()); ?></div>
            <div class="col-md-5"></div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebBanDienThoai\resources\views/admin/manufacturer/listManufacturer.blade.php ENDPATH**/ ?>