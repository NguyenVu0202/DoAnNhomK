


<!-- Product section-->
<?php $__env->startSection('content'); ?>
<main>
    <form action="<?php echo e(route('cart.addCard')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6"><img src="<?php echo e(asset('uploads/productimage/' . $product->image_address_product)); ?>"
                    alt="" style="width: 80%; height: 500px;"></div>
            <div class="col-md-6" style="margin-top:150px;">
            <input type="hidden" name="id_product" value="<?php echo e($product->id_product); ?>">
                <h1><?php echo e($product->name_product); ?></h1>
                <h4 style="color:red;font-weight:600;"><?php echo e($product->price_product); ?> VND</h4>
                <p style="color:gray;font-weight:600;">Kho: <?php echo e($product->quantity_product); ?> </p>
                <div class="row">
                    <div class="col-md-6">
                        <h4 style="color: gray;margin-top:20px;">Quantity </h4>
                    </div>
                    <div class="col-md-6">
                        <div class="wrapper">
                            <span class="minus">-</span>
                            <input type="text" class="num" name="quantity_cart" id="quantity_cart" value="1">
                            <span class="plus">+</span>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-warning btn-addCart">Thêm vào giỏ hàng</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <h1>Mô tả sản phẩm</h1>
                <?php echo e($product->describe_product); ?>

            </div>
            <div class="col-md-1"></div>
            <div class="col-md-5">
                <h4>Cấu hình điện thoại <?php echo e($product->name_product); ?></h4>
                <div class="row">
                    <div class="col-md-6" style="background: #f5f5f5;">Màn hình:</div>
                    <div class="col-md-6" style="background: #f5f5f5;"><?php echo e($specifications[0]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6">Chip xử lý:</div>
                    <div class="col-md-6"><?php echo e($specifications[1]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6" style="background: #f5f5f5;">Ram:</div>
                    <div class="col-md-6" style="background: #f5f5f5;"><?php echo e($specifications[2]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6">Bộ nhớ trong:</div>
                    <div class="col-md-6"><?php echo e($specifications[3]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6" style="background: #f5f5f5;">Pin:</div>
                    <div class="col-md-6" style="background: #f5f5f5;"><?php echo e($specifications[4]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6">Camera sau:</div>
                    <div class="col-md-6"><?php echo e($specifications[5]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6" style="background: #f5f5f5;">Camera trước:</div>
                    <div class="col-md-6" style="background: #f5f5f5;"><?php echo e($specifications[6]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6">Cổng sạc:</div>
                    <div class="col-md-6"><?php echo e($specifications[7]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6" style="background: #f5f5f5;">Kích thước:</div>
                    <div class="col-md-6" style="background: #f5f5f5;"><?php echo e($specifications[8]); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-6">Màu sắc:</div>
                    <div class="col-md-6"><?php echo e($specifications[9]); ?></div>
                </div>
            </div>
            
        </div>

    </div>
    </form>
</main>
<style>
.wrapper {
    height: 40px;
    min-width: 180px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #FFF;
    border-radius: 12px;
    box-shadow: 10px 10px 10px rgba(0, 0, 0, 0.2);
    border-radius: 12px;
    border: 1px solid rgba(0, 0, 0, 0.2);
    margin-top: 20px;
}

.wrapper span {
    width: 100%;
    text-align: center;
    font-size: 20px;
    font-weight: 600;
    cursor: pointer;
}

.wrapper input[type='text']{
    width: 100%;
    font-size: 20px;
    border-right: 2px solid rgba(0, 0, 0, 0.2) !important;
    border-left: 2px solid rgba(0, 0, 0, 0.2) !important;
    pointer-events: none;
    border: none;
    text-align: center;
}

.btn-addCart{
    color: #FFF;
    font-weight: 600;
    font-size: 20px;
    margin-top: 40px;
}

.btn-addCart:hover{
    color: #FFF;
}

footer{
    text-align: center;
    margin-top:80px;
    background:red;
    padding-top: 20px;
    padding-bottom: 20px;
    font-weight: 600;
    font-size: 20px;
    color: #FFF;
}
</style>
<script>
const plus = document.querySelector(".plus"),
    minus = document.querySelector(".minus"),
    num = document.querySelector(".num");
let a = 1;
plus.addEventListener("click", () => {
    a++;
    num.value = a;
});
minus.addEventListener("click", () => {
    if (a > 1) {
        a--;
        num.value = a;
    }

});
</script>
<footer>Web bán điện thoại</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Data\WebBanDienThoai\WebBanDienThoai\resources\views/user/detailproduct.blade.php ENDPATH**/ ?>