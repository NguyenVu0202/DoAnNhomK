<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function addOrder(Request $request)
    {
        $user_id = session('cart')['user_id'];
        $data = $request->all();
        $total = $data['total'];
        
        Order::create([
            'id_user' => $user_id,
            'total_order' => $total,
            'address' => ""
        ]);

        return redirect()->route('payment.paymentindex');
    }
}
